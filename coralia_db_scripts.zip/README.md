# Coralía DB Scripts (Local)

## 1. Crear DB y usuario app
MONGO_DB=coralia_dev MONGO_URI="mongodb://localhost:27017" \
  mongosh "$MONGO_URI" --eval 'process.env=(_=>this)()' scripts/db/init/00-create-db.js

## 2. Crear colecciones
MONGO_DB=coralia_dev MONGO_URI="mongodb://localhost:27017" \
  mongosh "$MONGO_URI" --eval 'process.env=(_=>this)()' scripts/db/init/01-collections.js

## 3. Crear índices
MONGO_DB=coralia_dev MONGO_URI="mongodb://localhost:27017" \
  mongosh "$MONGO_URI" --eval 'process.env=(_=>this)()' scripts/db/init/02-indexes.js

## 4. Crear admin utilitario
ADMIN_EMAIL=admin@coralia.mx MONGO_DB=coralia_dev MONGO_URI="mongodb://localhost:27017" \
  mongosh "$MONGO_URI" --eval 'process.env=(_=>this)()' scripts/db/utils/ensure_admin.js

## 5. Importar seeds
mongoimport --uri "mongodb://localhost:27017/coralia_dev" --collection users --file scripts/db/seed/users.json --jsonArray
