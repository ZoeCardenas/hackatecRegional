const DB_NAME = process.env.MONGO_DB || 'coralia_dev';
const dbRef = db.getSiblingDB(DB_NAME);
const email = process.env.ADMIN_EMAIL || 'admin@coralia.mx';
const now = new Date();
const existing = dbRef.users.findOne({ email });
if (!existing) {
  dbRef.users.insertOne({
    email,role:'admin',status:'active',
    oauth:{provider:'password',sub:'local-admin'},
    created_at:now,updated_at:now
  });
} else {
  print('Admin already exists.');
}
