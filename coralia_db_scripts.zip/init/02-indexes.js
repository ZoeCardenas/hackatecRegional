const DB_NAME = process.env.MONGO_DB || 'coralia_dev';
const dbRef = db.getSiblingDB(DB_NAME);
dbRef.users.createIndex({ email: 1 }, { unique: true, name: 'uniq_email' });
