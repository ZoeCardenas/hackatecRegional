const DB_NAME = process.env.MONGO_DB || 'coralia_dev';
const dbRef = db.getSiblingDB(DB_NAME);
print(`Using DB: ${DB_NAME}`);
const APP_USER = process.env.MONGO_APP_USER;
const APP_PASS = process.env.MONGO_APP_PASS;
if (APP_USER && APP_PASS) {
  try {
    dbRef.createUser({user: APP_USER,pwd: APP_PASS,roles: [{ role: 'readWrite', db: DB_NAME }]});
    print('App user created.');
  } catch (e) {
    if (e.codeName === 'DuplicateKey') print('App user already exists.');
    else throw e;
  }
}
