const DB_NAME = process.env.MONGO_DB || 'coralia_dev';
const dbRef = db.getSiblingDB(DB_NAME);
function createOrUpdate(name, validator) {
  if (dbRef.getCollectionNames().includes(name)) {
    dbRef.runCommand({ collMod: name, validator, validationLevel: 'moderate' });
  } else {
    dbRef.createCollection(name, { validator, validationLevel: 'moderate' });
  }
}
createOrUpdate('users', {
  $jsonSchema: {
    bsonType: 'object',
    required: ['email','role','status','created_at'],
    properties: {
      email: {bsonType:'string',pattern:'^.+@.+\\..+$'},
      role: {enum:['user','therapist','admin']},
      status:{enum:['active','inactive','blocked']},
      created_at:{bsonType:'date'},updated_at:{bsonType:'date'}
    }
  }
});
